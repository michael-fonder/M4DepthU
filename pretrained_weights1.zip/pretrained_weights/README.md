# Pre-trained weights

These weights correspond to the five network trainings made for our experiments. All our results are based on these set of weights.
